"use client"

import { Flame, Zap, Gauge, BarChart3 } from "lucide-react"
import {
  LineChart,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
} from "recharts"
import { motion } from "framer-motion"
import { useCsvData } from "@/context/csv-data-context"
import { AnimatedPage } from "@/components/animated-page"
import { KpiCard } from "@/components/kpi-card"
import { NoDataWarning } from "@/components/no-data-warning"

const EMISSION_FACTOR = 0.42

function CustomTooltip({
  active,
  payload,
  label,
}: {
  active?: boolean
  payload?: Array<{ value: number; name: string; color: string }>
  label?: string
}) {
  if (!active || !payload?.length) return null
  return (
    <div className="rounded-lg border border-border bg-card px-3 py-2 shadow-lg">
      <p className="text-xs font-medium text-muted-foreground">
        Record {label}
      </p>
      {payload.map((entry) => (
        <p key={entry.name} className="text-sm font-semibold" style={{ color: entry.color }}>
          {entry.name}: {entry.value.toFixed(2)}
        </p>
      ))}
    </div>
  )
}

export default function DashboardPage() {
  const { data, hasData } = useCsvData()

  if (!hasData) {
    return (
      <AnimatedPage>
        <h1 className="text-2xl font-bold text-foreground">Dashboard Overview</h1>
        <p className="mt-1 text-sm text-muted-foreground">
          Real-time emission metrics and analytics
        </p>
        <NoDataWarning />
      </AnimatedPage>
    )
  }

  const totalEmission = data.reduce(
    (sum, r) => sum + r.energy_kwh * EMISSION_FACTOR,
    0
  )
  const totalEnergy = data.reduce((sum, r) => sum + r.energy_kwh, 0)
  const avgEfficiency =
    data.reduce((sum, r) => sum + (100 - r.idle_percentage), 0) / data.length
  const carbonIntensity =
    totalEmission / data.reduce((sum, r) => sum + r.production_units, 0)

  const emissionChartData = data.map((r, i) => ({
    index: i + 1,
    emission: +(r.energy_kwh * EMISSION_FACTOR).toFixed(2),
  }))

  const energyChartData = data.map((r, i) => ({
    index: i + 1,
    energy: +r.energy_kwh.toFixed(2),
  }))

  return (
    <AnimatedPage>
      <h1 className="text-2xl font-bold text-foreground">Dashboard Overview</h1>
      <p className="mt-1 text-sm text-muted-foreground">
        Real-time emission metrics and analytics
      </p>

      <div className="mt-6 grid gap-4 md:grid-cols-2 lg:grid-cols-4">
        <KpiCard
          title="Total CO2 Emission"
          value={`${totalEmission.toFixed(1)} kg`}
          subtitle="Predicted from operational data"
          icon={Flame}
          delay={0}
        />
        <KpiCard
          title="Energy Consumption"
          value={`${totalEnergy.toFixed(0)} kWh`}
          subtitle="Cumulative energy usage"
          icon={Zap}
          delay={0.1}
        />
        <KpiCard
          title="Avg Efficiency Score"
          value={`${avgEfficiency.toFixed(1)}%`}
          subtitle="Operational efficiency"
          icon={Gauge}
          delay={0.2}
        />
        <KpiCard
          title="Carbon Intensity"
          value={`${carbonIntensity.toFixed(3)}`}
          subtitle="kg CO2 per production unit"
          icon={BarChart3}
          delay={0.3}
        />
      </div>

      <div className="mt-6 grid gap-6 lg:grid-cols-2">
        <motion.div
          initial={{ opacity: 0, y: 16 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5, delay: 0.4 }}
          className="rounded-xl border border-border bg-card p-5"
        >
          <h3 className="text-sm font-semibold text-foreground">Emission Trend</h3>
          <p className="mb-4 text-xs text-muted-foreground">
            CO2 emission per record (kg)
          </p>
          <ResponsiveContainer width="100%" height={260}>
            <LineChart data={emissionChartData}>
              <CartesianGrid strokeDasharray="3 3" stroke="hsl(150 6% 16%)" />
              <XAxis
                dataKey="index"
                tick={{ fontSize: 11, fill: "hsl(150 8% 50%)" }}
                axisLine={{ stroke: "hsl(150 6% 16%)" }}
                tickLine={false}
              />
              <YAxis
                tick={{ fontSize: 11, fill: "hsl(150 8% 50%)" }}
                axisLine={{ stroke: "hsl(150 6% 16%)" }}
                tickLine={false}
              />
              <Tooltip content={<CustomTooltip />} />
              <Line
                type="monotone"
                dataKey="emission"
                name="Emission (kg)"
                stroke="hsl(152 56% 48%)"
                strokeWidth={2}
                dot={false}
                activeDot={{ r: 4, fill: "hsl(152 56% 48%)" }}
              />
            </LineChart>
          </ResponsiveContainer>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 16 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5, delay: 0.5 }}
          className="rounded-xl border border-border bg-card p-5"
        >
          <h3 className="text-sm font-semibold text-foreground">Energy Usage</h3>
          <p className="mb-4 text-xs text-muted-foreground">
            Energy consumption per record (kWh)
          </p>
          <ResponsiveContainer width="100%" height={260}>
            <LineChart data={energyChartData}>
              <CartesianGrid strokeDasharray="3 3" stroke="hsl(150 6% 16%)" />
              <XAxis
                dataKey="index"
                tick={{ fontSize: 11, fill: "hsl(150 8% 50%)" }}
                axisLine={{ stroke: "hsl(150 6% 16%)" }}
                tickLine={false}
              />
              <YAxis
                tick={{ fontSize: 11, fill: "hsl(150 8% 50%)" }}
                axisLine={{ stroke: "hsl(150 6% 16%)" }}
                tickLine={false}
              />
              <Tooltip content={<CustomTooltip />} />
              <Line
                type="monotone"
                dataKey="energy"
                name="Energy (kWh)"
                stroke="hsl(38 92% 55%)"
                strokeWidth={2}
                dot={false}
                activeDot={{ r: 4, fill: "hsl(200 70% 50%)" }}
              />
            </LineChart>
          </ResponsiveContainer>
        </motion.div>
      </div>
    </AnimatedPage>
  )
}
