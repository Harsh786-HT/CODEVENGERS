import Image from "next/image"
import { AppSidebar } from "@/components/app-sidebar"

export default function DashboardLayout({
  children,
}: {
  children: React.ReactNode
}) {
  return (
    <div className="relative flex min-h-screen bg-background">
      {/* Background texture */}
      <div className="pointer-events-none fixed inset-0 z-0">
        <Image
          src="/images/dashboard-bg.jpg"
          alt=""
          fill
          sizes="100vw"
          loading="eager"
          className="object-cover opacity-10"
        />
        <div className="absolute inset-0 bg-background/80" />
      </div>
      <AppSidebar />
      <main className="relative z-10 flex-1 pl-64">
        <div className="p-6 lg:p-8">{children}</div>
      </main>
    </div>
  )
}
