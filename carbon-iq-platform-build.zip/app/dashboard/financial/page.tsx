"use client"

import { useMemo } from "react"
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
} from "recharts"
import { motion } from "framer-motion"
import { DollarSign, TrendingDown, Calculator, Calendar } from "lucide-react"
import { useCsvData } from "@/context/csv-data-context"
import { AnimatedPage } from "@/components/animated-page"
import { KpiCard } from "@/components/kpi-card"
import { NoDataWarning } from "@/components/no-data-warning"

const RATE_PER_KWH = 8

function FinTooltip({
  active,
  payload,
  label,
}: {
  active?: boolean
  payload?: Array<{ value: number; name: string; color: string }>
  label?: string
}) {
  if (!active || !payload?.length) return null
  return (
    <div className="rounded-lg border border-border bg-card px-3 py-2 shadow-lg">
      <p className="mb-1 text-xs font-medium text-muted-foreground">{label}</p>
      {payload.map((entry) => (
        <p key={entry.name} className="text-sm font-semibold" style={{ color: entry.color }}>
          {entry.name}: {"\u20B9"}{entry.value.toLocaleString("en-IN")}
        </p>
      ))}
    </div>
  )
}

export default function FinancialPage() {
  const { data, hasData, optimizedData, isOptimized } = useCsvData()

  const financials = useMemo(() => {
    if (!hasData) return null

    const totalEnergy = data.reduce((s, r) => s + r.energy_kwh, 0)
    const monthlyCost = totalEnergy * RATE_PER_KWH
    const annualCost = monthlyCost * 12

    if (!isOptimized || !optimizedData) {
      return {
        totalEnergy,
        monthlyCost,
        annualCost,
        optimizedEnergy: 0,
        monthlySavings: 0,
        annualSavings: 0,
        optimizedMonthlyCost: 0,
        optimizedAnnualCost: 0,
      }
    }

    const optimizedEnergy = optimizedData.reduce((s, r) => s + r.energy_kwh, 0)
    const optimizedMonthlyCost = optimizedEnergy * RATE_PER_KWH
    const optimizedAnnualCost = optimizedMonthlyCost * 12
    const monthlySavings = monthlyCost - optimizedMonthlyCost
    const annualSavings = annualCost - optimizedAnnualCost

    return {
      totalEnergy,
      monthlyCost,
      annualCost,
      optimizedEnergy,
      monthlySavings,
      annualSavings,
      optimizedMonthlyCost,
      optimizedAnnualCost,
    }
  }, [data, hasData, optimizedData, isOptimized])

  if (!hasData || !financials) {
    return (
      <AnimatedPage>
        <h1 className="text-2xl font-bold text-foreground">Financial Impact</h1>
        <p className="mt-1 text-sm text-muted-foreground">
          Cost analysis and savings projection
        </p>
        <NoDataWarning />
      </AnimatedPage>
    )
  }

  const barData = [
    {
      name: "Monthly",
      current: Math.round(financials.monthlyCost),
      ...(isOptimized ? { optimized: Math.round(financials.optimizedMonthlyCost) } : {}),
    },
    {
      name: "Annual",
      current: Math.round(financials.annualCost),
      ...(isOptimized ? { optimized: Math.round(financials.optimizedAnnualCost) } : {}),
    },
  ]

  return (
    <AnimatedPage>
      <div className="flex items-center gap-3">
        <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-primary/10">
          <DollarSign className="h-5 w-5 text-primary" />
        </div>
        <div>
          <h1 className="text-2xl font-bold text-foreground">Financial Impact</h1>
          <p className="text-sm text-muted-foreground">
            Cost analysis and savings projection
          </p>
        </div>
      </div>

      {/* Current costs */}
      <div className="mt-6 grid gap-4 md:grid-cols-2 lg:grid-cols-4">
        <KpiCard
          title="Monthly Energy Cost"
          value={`\u20B9${financials.monthlyCost.toLocaleString("en-IN")}`}
          subtitle={`${financials.totalEnergy.toFixed(0)} kWh x \u20B9${RATE_PER_KWH}/kWh`}
          icon={Calculator}
          delay={0.1}
        />
        <KpiCard
          title="Annual Projection"
          value={`\u20B9${financials.annualCost.toLocaleString("en-IN")}`}
          subtitle="12-month extrapolation"
          icon={Calendar}
          delay={0.2}
        />
        {isOptimized && (
          <>
            <KpiCard
              title="Monthly Savings"
              value={`\u20B9${financials.monthlySavings.toLocaleString("en-IN")}`}
              subtitle="After optimization"
              icon={TrendingDown}
              trend={`${((financials.monthlySavings / financials.monthlyCost) * 100).toFixed(1)}% reduction`}
              trendUp
              delay={0.3}
            />
            <KpiCard
              title="Annual Savings"
              value={`\u20B9${financials.annualSavings.toLocaleString("en-IN")}`}
              subtitle="Projected yearly savings"
              icon={DollarSign}
              trend={`\u20B9${Math.round(financials.annualSavings / 12).toLocaleString("en-IN")}/month avg`}
              trendUp
              delay={0.4}
            />
          </>
        )}
      </div>

      {/* Cost breakdown */}
      <motion.div
        initial={{ opacity: 0, y: 16 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5, delay: 0.5 }}
        className="mt-6 rounded-xl border border-border bg-card p-5"
      >
        <h3 className="text-sm font-semibold text-foreground">
          Cost Comparison
        </h3>
        <p className="mb-4 text-xs text-muted-foreground">
          {isOptimized
            ? "Current vs optimized energy costs"
            : "Current energy costs (run optimization to compare)"}
        </p>
        <ResponsiveContainer width="100%" height={300}>
          <BarChart data={barData} barGap={8}>
            <CartesianGrid strokeDasharray="3 3" stroke="hsl(150 6% 16%)" />
            <XAxis
              dataKey="name"
              tick={{ fontSize: 12, fill: "hsl(150 8% 50%)" }}
              axisLine={{ stroke: "hsl(150 6% 16%)" }}
              tickLine={false}
            />
            <YAxis
              tick={{ fontSize: 11, fill: "hsl(150 8% 50%)" }}
              axisLine={{ stroke: "hsl(150 6% 16%)" }}
              tickLine={false}
              tickFormatter={(v) => `\u20B9${(v / 1000).toFixed(0)}k`}
            />
            <Tooltip content={<FinTooltip />} />
            <Bar
              dataKey="current"
              name="Current Cost"
              fill="hsl(150 6% 25%)"
              radius={[6, 6, 0, 0]}
              barSize={60}
            />
            {isOptimized && (
              <Bar
                dataKey="optimized"
                name="Optimized Cost"
                fill="hsl(152 56% 48%)"
                radius={[6, 6, 0, 0]}
                barSize={60}
              />
            )}
          </BarChart>
        </ResponsiveContainer>
      </motion.div>

      {/* Detailed breakdown table */}
      {isOptimized && (
        <motion.div
          initial={{ opacity: 0, y: 16 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5, delay: 0.6 }}
          className="mt-6 overflow-hidden rounded-xl border border-border bg-card"
        >
          <div className="border-b border-border px-5 py-3">
            <h3 className="text-sm font-semibold text-foreground">Savings Breakdown</h3>
          </div>
          <div className="overflow-x-auto">
            <table className="w-full text-left text-sm">
              <thead>
                <tr className="border-b border-border bg-secondary/50">
                  <th className="px-5 py-3 font-semibold text-muted-foreground">Metric</th>
                  <th className="px-5 py-3 font-semibold text-muted-foreground">Before</th>
                  <th className="px-5 py-3 font-semibold text-muted-foreground">After</th>
                  <th className="px-5 py-3 font-semibold text-muted-foreground">Savings</th>
                </tr>
              </thead>
              <tbody>
                <tr className="border-b border-border/50">
                  <td className="px-5 py-3 text-foreground">Monthly Cost</td>
                  <td className="px-5 py-3 font-mono text-foreground">
                    {"\u20B9"}{financials.monthlyCost.toLocaleString("en-IN")}
                  </td>
                  <td className="px-5 py-3 font-mono text-primary">
                    {"\u20B9"}{financials.optimizedMonthlyCost.toLocaleString("en-IN")}
                  </td>
                  <td className="px-5 py-3 font-mono font-medium text-emerald-400">
                    {"\u20B9"}{financials.monthlySavings.toLocaleString("en-IN")}
                  </td>
                </tr>
                <tr className="border-b border-border/50">
                  <td className="px-5 py-3 text-foreground">Annual Cost</td>
                  <td className="px-5 py-3 font-mono text-foreground">
                    {"\u20B9"}{financials.annualCost.toLocaleString("en-IN")}
                  </td>
                  <td className="px-5 py-3 font-mono text-primary">
                    {"\u20B9"}{financials.optimizedAnnualCost.toLocaleString("en-IN")}
                  </td>
                  <td className="px-5 py-3 font-mono font-medium text-emerald-400">
                    {"\u20B9"}{financials.annualSavings.toLocaleString("en-IN")}
                  </td>
                </tr>
                <tr>
                  <td className="px-5 py-3 text-foreground">Energy Usage</td>
                  <td className="px-5 py-3 font-mono text-foreground">
                    {financials.totalEnergy.toFixed(0)} kWh
                  </td>
                  <td className="px-5 py-3 font-mono text-primary">
                    {financials.optimizedEnergy.toFixed(0)} kWh
                  </td>
                  <td className="px-5 py-3 font-mono font-medium text-emerald-400">
                    {(financials.totalEnergy - financials.optimizedEnergy).toFixed(0)} kWh
                  </td>
                </tr>
              </tbody>
            </table>
          </div>
        </motion.div>
      )}

      {!isOptimized && (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ duration: 0.5, delay: 0.5 }}
          className="mt-6 rounded-xl border border-border bg-secondary/30 p-6 text-center"
        >
          <p className="text-sm text-muted-foreground">
            Run optimization on the Optimization page to see projected savings and cost comparisons.
          </p>
        </motion.div>
      )}
    </AnimatedPage>
  )
}
