"use client"

import { useMemo } from "react"
import {
  AreaChart,
  Area,
  LineChart,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  RadarChart,
  Radar,
  PolarGrid,
  PolarAngleAxis,
  PolarRadiusAxis,
  ScatterChart,
  Scatter,
} from "recharts"
import { motion } from "framer-motion"
import { Activity, Thermometer, Volume2, Zap, Gauge, AlertTriangle } from "lucide-react"
import { useCsvData } from "@/context/csv-data-context"
import { AnimatedPage } from "@/components/animated-page"
import { NoDataWarning } from "@/components/no-data-warning"
import { cn } from "@/lib/utils"

const GRID = "hsl(150 6% 16%)"
const TICK = "hsl(150 8% 50%)"
const GREEN = "hsl(152 56% 48%)"
const AMBER = "hsl(38 92% 55%)"
const BLUE = "hsl(200 65% 50%)"
const RED = "hsl(0 72% 51%)"

function ChartTooltip({
  active,
  payload,
  label,
}: {
  active?: boolean
  payload?: Array<{ value: number; name: string; color: string }>
  label?: string
}) {
  if (!active || !payload?.length) return null
  return (
    <div className="rounded-lg border border-border bg-card/95 px-3 py-2 shadow-xl backdrop-blur-sm">
      <p className="mb-1 text-[10px] font-semibold uppercase tracking-wider text-muted-foreground">
        Record {label}
      </p>
      {payload.map((entry) => (
        <p key={entry.name} className="text-xs font-semibold" style={{ color: entry.color }}>
          {entry.name}: {typeof entry.value === "number" ? entry.value.toFixed(2) : entry.value}
        </p>
      ))}
    </div>
  )
}

function GaugeCard({
  label,
  value,
  unit,
  max,
  icon: Icon,
  color,
  delay,
}: {
  label: string
  value: number
  unit: string
  max: number
  icon: typeof Activity
  color: string
  delay: number
}) {
  const pct = Math.min((value / max) * 100, 100)
  const riskColor = pct > 85 ? RED : pct > 60 ? AMBER : GREEN

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5, delay }}
      className="group relative overflow-hidden rounded-xl border border-border bg-card p-5"
    >
      <div className="absolute inset-0 bg-gradient-to-br from-transparent to-primary/[0.02] opacity-0 transition-opacity group-hover:opacity-100" />
      <div className="relative flex items-center justify-between">
        <div>
          <p className="text-[11px] font-semibold uppercase tracking-wider text-muted-foreground">
            {label}
          </p>
          <p className="mt-1 text-2xl font-bold tracking-tight text-foreground">
            {value.toFixed(1)}
            <span className="ml-1 text-sm font-normal text-muted-foreground">{unit}</span>
          </p>
        </div>
        <div
          className="flex h-10 w-10 items-center justify-center rounded-lg"
          style={{ backgroundColor: `${color}15` }}
        >
          <Icon className="h-5 w-5" style={{ color }} />
        </div>
      </div>
      {/* Progress bar gauge */}
      <div className="relative mt-4 h-2 overflow-hidden rounded-full bg-secondary">
        <motion.div
          initial={{ width: 0 }}
          animate={{ width: `${pct}%` }}
          transition={{ duration: 1.2, delay: delay + 0.3, ease: "easeOut" }}
          className="absolute inset-y-0 left-0 rounded-full"
          style={{ backgroundColor: riskColor }}
        />
      </div>
      <div className="mt-1.5 flex items-center justify-between text-[10px] text-muted-foreground">
        <span>0</span>
        <span
          className="font-semibold"
          style={{ color: riskColor }}
        >
          {pct.toFixed(0)}% of threshold
        </span>
        <span>{max}</span>
      </div>
    </motion.div>
  )
}

function SignalStrip({
  data,
  dataKey,
  color,
  label,
  delay,
}: {
  data: Array<Record<string, number>>
  dataKey: string
  color: string
  label: string
  delay: number
}) {
  return (
    <motion.div
      initial={{ opacity: 0, x: -20 }}
      animate={{ opacity: 1, x: 0 }}
      transition={{ duration: 0.5, delay }}
      className="flex items-center gap-4 rounded-lg border border-border bg-card/60 px-4 py-3 backdrop-blur-sm"
    >
      <div className="w-24 shrink-0">
        <p className="text-[11px] font-semibold uppercase tracking-wider text-muted-foreground">
          {label}
        </p>
        <p className="mt-0.5 text-sm font-bold text-foreground">
          {data.length > 0 ? data[data.length - 1][dataKey]?.toFixed(1) : "--"}
        </p>
      </div>
      <div className="h-12 flex-1">
        <ResponsiveContainer width="100%" height="100%">
          <AreaChart data={data.slice(-30)}>
            <defs>
              <linearGradient id={`grad-${dataKey}`} x1="0" y1="0" x2="0" y2="1">
                <stop offset="0%" stopColor={color} stopOpacity={0.3} />
                <stop offset="100%" stopColor={color} stopOpacity={0} />
              </linearGradient>
            </defs>
            <Area
              type="monotone"
              dataKey={dataKey}
              stroke={color}
              strokeWidth={1.5}
              fill={`url(#grad-${dataKey})`}
              dot={false}
            />
          </AreaChart>
        </ResponsiveContainer>
      </div>
    </motion.div>
  )
}

export default function SignalsPage() {
  const { data, hasData, analytics } = useCsvData()

  const chartData = useMemo(() => {
    if (!hasData) return []
    return data.map((r, i) => ({
      index: i + 1,
      energy: +r.energy_kwh.toFixed(2),
      temperature: +r.avg_temperature.toFixed(2),
      noise: +r.machine_noise_db.toFixed(2),
      idle: +r.idle_percentage.toFixed(2),
      production: r.production_units,
      hours: r.operating_hours,
    }))
  }, [data, hasData])

  const radarData = useMemo(() => {
    if (!analytics) return []
    return [
      { signal: "Energy", value: (analytics.avgEnergy / analytics.peakEnergy) * 100, fullMark: 100 },
      { signal: "Temp", value: Math.min((analytics.avgTemperature / 120) * 100, 100), fullMark: 100 },
      { signal: "Noise", value: Math.min((analytics.avgNoise / 120) * 100, 100), fullMark: 100 },
      { signal: "Efficiency", value: analytics.avgEfficiency, fullMark: 100 },
      { signal: "Idle", value: analytics.avgIdlePercent, fullMark: 100 },
      { signal: "Output", value: Math.min((analytics.totalProduction / (analytics.totalRecords * 100)) * 100, 100), fullMark: 100 },
    ]
  }, [analytics])

  const correlationData = useMemo(() => {
    if (!hasData) return []
    return data.map((r) => ({
      energy: +r.energy_kwh.toFixed(2),
      emission: +(r.energy_kwh * 0.42).toFixed(2),
    }))
  }, [data, hasData])

  if (!hasData || !analytics) {
    return (
      <AnimatedPage>
        <div className="flex items-center gap-3">
          <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-primary/10">
            <Activity className="h-5 w-5 text-primary" />
          </div>
          <div>
            <h1 className="text-2xl font-bold text-foreground">Signal Monitoring</h1>
            <p className="text-sm text-muted-foreground">
              Industrial signal visualization and anomaly detection
            </p>
          </div>
        </div>
        <NoDataWarning />
      </AnimatedPage>
    )
  }

  return (
    <AnimatedPage>
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-primary/10">
            <Activity className="h-5 w-5 text-primary" />
          </div>
          <div>
            <h1 className="text-2xl font-bold text-foreground">Signal Monitoring</h1>
            <p className="text-sm text-muted-foreground">
              Live operational signal analysis across {analytics.totalRecords} data points
            </p>
          </div>
        </div>
        {analytics.anomalyIndices.length > 0 && (
          <motion.div
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            className="flex items-center gap-2 rounded-lg border border-destructive/30 bg-destructive/10 px-3 py-2"
          >
            <AlertTriangle className="h-4 w-4 text-destructive" />
            <span className="text-xs font-semibold text-destructive">
              {analytics.anomalyIndices.length} anomalies detected
            </span>
          </motion.div>
        )}
      </div>

      {/* Gauge Cards Row */}
      <div className="mt-6 grid gap-4 md:grid-cols-2 lg:grid-cols-4">
        <GaugeCard
          label="Avg Energy"
          value={analytics.avgEnergy}
          unit="kWh"
          max={analytics.peakEnergy * 1.2}
          icon={Zap}
          color={GREEN}
          delay={0.1}
        />
        <GaugeCard
          label="Avg Temperature"
          value={analytics.avgTemperature}
          unit="C"
          max={120}
          icon={Thermometer}
          color={AMBER}
          delay={0.15}
        />
        <GaugeCard
          label="Avg Noise"
          value={analytics.avgNoise}
          unit="dB"
          max={110}
          icon={Volume2}
          color={BLUE}
          delay={0.2}
        />
        <GaugeCard
          label="Efficiency"
          value={analytics.avgEfficiency}
          unit="%"
          max={100}
          icon={Gauge}
          color={analytics.avgEfficiency > 80 ? GREEN : analytics.avgEfficiency > 60 ? AMBER : RED}
          delay={0.25}
        />
      </div>

      {/* Live Signal Strips */}
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ duration: 0.3, delay: 0.3 }}
        className="mt-6"
      >
        <h3 className="mb-3 text-xs font-semibold uppercase tracking-wider text-muted-foreground">
          Signal Streams
        </h3>
        <div className="grid gap-3 md:grid-cols-2">
          <SignalStrip data={chartData} dataKey="energy" color={GREEN} label="Energy" delay={0.35} />
          <SignalStrip data={chartData} dataKey="temperature" color={AMBER} label="Thermal" delay={0.4} />
          <SignalStrip data={chartData} dataKey="noise" color={BLUE} label="Acoustic" delay={0.45} />
          <SignalStrip data={chartData} dataKey="idle" color={RED} label="Idle %" delay={0.5} />
        </div>
      </motion.div>

      {/* Multi-Signal Overlay Chart */}
      <motion.div
        initial={{ opacity: 0, y: 16 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5, delay: 0.55 }}
        className="mt-6 rounded-xl border border-border bg-card p-5"
      >
        <div className="mb-4 flex items-center justify-between">
          <div>
            <h3 className="text-sm font-semibold text-foreground">Multi-Signal Overlay</h3>
            <p className="text-xs text-muted-foreground">Energy, temperature, and noise normalized trends</p>
          </div>
          <div className="flex items-center gap-4">
            {[
              { label: "Energy", color: GREEN },
              { label: "Temp", color: AMBER },
              { label: "Noise", color: BLUE },
            ].map((item) => (
              <div key={item.label} className="flex items-center gap-1.5">
                <div className="h-2 w-2 rounded-full" style={{ backgroundColor: item.color }} />
                <span className="text-[10px] text-muted-foreground">{item.label}</span>
              </div>
            ))}
          </div>
        </div>
        <ResponsiveContainer width="100%" height={300}>
          <AreaChart data={chartData}>
            <defs>
              <linearGradient id="energyGrad" x1="0" y1="0" x2="0" y2="1">
                <stop offset="0%" stopColor={GREEN} stopOpacity={0.2} />
                <stop offset="100%" stopColor={GREEN} stopOpacity={0} />
              </linearGradient>
              <linearGradient id="tempGrad" x1="0" y1="0" x2="0" y2="1">
                <stop offset="0%" stopColor={AMBER} stopOpacity={0.15} />
                <stop offset="100%" stopColor={AMBER} stopOpacity={0} />
              </linearGradient>
            </defs>
            <CartesianGrid strokeDasharray="3 3" stroke={GRID} />
            <XAxis dataKey="index" tick={{ fontSize: 10, fill: TICK }} axisLine={{ stroke: GRID }} tickLine={false} />
            <YAxis tick={{ fontSize: 10, fill: TICK }} axisLine={{ stroke: GRID }} tickLine={false} />
            <Tooltip content={<ChartTooltip />} />
            <Area type="monotone" dataKey="energy" name="Energy (kWh)" stroke={GREEN} strokeWidth={2} fill="url(#energyGrad)" dot={false} />
            <Area type="monotone" dataKey="temperature" name="Temperature (C)" stroke={AMBER} strokeWidth={1.5} fill="url(#tempGrad)" dot={false} />
            <Line type="monotone" dataKey="noise" name="Noise (dB)" stroke={BLUE} strokeWidth={1.5} dot={false} strokeDasharray="4 2" />
          </AreaChart>
        </ResponsiveContainer>
      </motion.div>

      <div className="mt-6 grid gap-6 lg:grid-cols-2">
        {/* Radar Chart */}
        <motion.div
          initial={{ opacity: 0, y: 16 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5, delay: 0.6 }}
          className="rounded-xl border border-border bg-card p-5"
        >
          <h3 className="text-sm font-semibold text-foreground">Signal Profile Radar</h3>
          <p className="mb-2 text-xs text-muted-foreground">Normalized operational metrics</p>
          <ResponsiveContainer width="100%" height={280}>
            <RadarChart data={radarData} cx="50%" cy="50%" outerRadius="70%">
              <PolarGrid stroke={GRID} />
              <PolarAngleAxis dataKey="signal" tick={{ fontSize: 10, fill: TICK }} />
              <PolarRadiusAxis tick={false} axisLine={false} />
              <Radar name="Current" dataKey="value" stroke={GREEN} fill={GREEN} fillOpacity={0.15} strokeWidth={2} />
            </RadarChart>
          </ResponsiveContainer>
        </motion.div>

        {/* Scatter: Energy vs Emission */}
        <motion.div
          initial={{ opacity: 0, y: 16 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5, delay: 0.65 }}
          className="rounded-xl border border-border bg-card p-5"
        >
          <h3 className="text-sm font-semibold text-foreground">Energy-Emission Correlation</h3>
          <p className="mb-2 text-xs text-muted-foreground">Scatter plot of energy vs predicted CO2</p>
          <ResponsiveContainer width="100%" height={280}>
            <ScatterChart>
              <CartesianGrid strokeDasharray="3 3" stroke={GRID} />
              <XAxis dataKey="energy" name="Energy (kWh)" tick={{ fontSize: 10, fill: TICK }} axisLine={{ stroke: GRID }} tickLine={false} />
              <YAxis dataKey="emission" name="CO2 (kg)" tick={{ fontSize: 10, fill: TICK }} axisLine={{ stroke: GRID }} tickLine={false} />
              <Tooltip content={<ChartTooltip />} />
              <Scatter name="Records" data={correlationData} fill={GREEN} fillOpacity={0.6} />
            </ScatterChart>
          </ResponsiveContainer>
        </motion.div>
      </div>

      {/* Anomaly Table */}
      {analytics.anomalyIndices.length > 0 && (
        <motion.div
          initial={{ opacity: 0, y: 16 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5, delay: 0.7 }}
          className="mt-6 overflow-hidden rounded-xl border border-destructive/20 bg-card"
        >
          <div className="flex items-center gap-2 border-b border-border bg-destructive/5 px-5 py-3">
            <AlertTriangle className="h-4 w-4 text-destructive" />
            <h3 className="text-sm font-semibold text-foreground">Anomalous Records</h3>
            <span className="ml-auto rounded-full bg-destructive/10 px-2 py-0.5 text-[10px] font-semibold text-destructive">
              {analytics.anomalyIndices.length} flagged
            </span>
          </div>
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead>
                <tr className="border-b border-border bg-secondary/30">
                  <th className="px-5 py-2.5 font-semibold text-muted-foreground">Record #</th>
                  <th className="px-5 py-2.5 font-semibold text-muted-foreground">Energy (kWh)</th>
                  <th className="px-5 py-2.5 font-semibold text-muted-foreground">Temperature</th>
                  <th className="px-5 py-2.5 font-semibold text-muted-foreground">Noise (dB)</th>
                  <th className="px-5 py-2.5 font-semibold text-muted-foreground">Deviation</th>
                </tr>
              </thead>
              <tbody>
                {analytics.anomalyIndices.slice(0, 10).map((idx) => {
                  const r = data[idx]
                  const deviation = ((r.energy_kwh - analytics.avgEnergy) / analytics.avgEnergy * 100)
                  return (
                    <tr key={idx} className="border-b border-border/30 last:border-0">
                      <td className="px-5 py-2.5 font-mono text-foreground">{idx + 1}</td>
                      <td className="px-5 py-2.5 font-mono font-semibold text-destructive">{r.energy_kwh.toFixed(1)}</td>
                      <td className="px-5 py-2.5 font-mono text-foreground">{r.avg_temperature.toFixed(1)}</td>
                      <td className="px-5 py-2.5 font-mono text-foreground">{r.machine_noise_db.toFixed(1)}</td>
                      <td className="px-5 py-2.5">
                        <span className="rounded bg-destructive/10 px-1.5 py-0.5 font-mono text-[10px] font-semibold text-destructive">
                          +{deviation.toFixed(1)}%
                        </span>
                      </td>
                    </tr>
                  )
                })}
              </tbody>
            </table>
          </div>
        </motion.div>
      )}
    </AnimatedPage>
  )
}
