"use client"

import { useState, useCallback, useRef } from "react"
import { motion, AnimatePresence } from "framer-motion"
import { Upload, FileSpreadsheet, CheckCircle2, AlertCircle, X, Leaf } from "lucide-react"
import { useCsvData, type CsvRecord } from "@/context/csv-data-context"
import { AnimatedPage } from "@/components/animated-page"
import { Button } from "@/components/ui/button"

const REQUIRED_FIELDS = [
  "energy_kwh",
  "operating_hours",
  "idle_percentage",
  "avg_temperature",
  "machine_noise_db",
  "production_units",
]

function parseCsv(text: string): { records: CsvRecord[]; error?: string } {
  const lines = text.trim().split("\n")
  if (lines.length < 2) return { records: [], error: "CSV must have at least a header and one data row." }

  const headers = lines[0].split(",").map((h) => h.trim())
  const missing = REQUIRED_FIELDS.filter((f) => !headers.includes(f))
  if (missing.length > 0) {
    return { records: [], error: `Missing required columns: ${missing.join(", ")}` }
  }

  const records: CsvRecord[] = []
  for (let i = 1; i < lines.length; i++) {
    const values = lines[i].split(",").map((v) => v.trim())
    if (values.length < headers.length) continue
    const row: Record<string, number> = {}
    headers.forEach((h, idx) => {
      row[h] = parseFloat(values[idx]) || 0
    })
    records.push({
      energy_kwh: row.energy_kwh,
      operating_hours: row.operating_hours,
      idle_percentage: row.idle_percentage,
      avg_temperature: row.avg_temperature,
      machine_noise_db: row.machine_noise_db,
      production_units: row.production_units,
    })
  }

  return { records }
}

export default function UploadPage() {
  const { data, setData, hasData } = useCsvData()
  const [dragOver, setDragOver] = useState(false)
  const [error, setError] = useState<string | null>(null)
  const [fileName, setFileName] = useState<string | null>(null)
  const inputRef = useRef<HTMLInputElement>(null)

  const handleFile = useCallback(
    (file: File) => {
      setError(null)
      if (!file.name.endsWith(".csv")) {
        setError("Only CSV files are accepted.")
        return
      }
      setFileName(file.name)
      const reader = new FileReader()
      reader.onload = (e) => {
        const text = e.target?.result as string
        const { records, error: parseError } = parseCsv(text)
        if (parseError) {
          setError(parseError)
          return
        }
        if (records.length === 0) {
          setError("No valid records found in the CSV file.")
          return
        }
        setData(records)
      }
      reader.readAsText(file)
    },
    [setData]
  )

  const handleDrop = useCallback(
    (e: React.DragEvent) => {
      e.preventDefault()
      setDragOver(false)
      const file = e.dataTransfer.files[0]
      if (file) handleFile(file)
    },
    [handleFile]
  )

  const handleInputChange = useCallback(
    (e: React.ChangeEvent<HTMLInputElement>) => {
      const file = e.target.files?.[0]
      if (file) handleFile(file)
    },
    [handleFile]
  )

  return (
    <AnimatedPage>
      <h1 className="text-2xl font-bold text-foreground">Data Upload</h1>
      <p className="mt-1 text-sm text-muted-foreground">
        Upload operational CSV data for emission analysis
      </p>

      <motion.div
        initial={{ opacity: 0, y: 16 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5, delay: 0.1 }}
        className="mt-6"
      >
        {/* Drop zone */}
        <div
          onDragOver={(e) => {
            e.preventDefault()
            setDragOver(true)
          }}
          onDragLeave={() => setDragOver(false)}
          onDrop={handleDrop}
          onClick={() => inputRef.current?.click()}
          className={`relative flex cursor-pointer flex-col items-center justify-center overflow-hidden rounded-xl border-2 border-dashed p-12 transition-colors ${
            dragOver
              ? "border-primary bg-primary/5"
              : "border-border bg-card hover:border-primary/50"
          }`}
        >
          {/* Decorative background leaves */}
          <Leaf className="pointer-events-none absolute right-6 top-6 h-24 w-24 rotate-12 text-primary/5" />
          <Leaf className="pointer-events-none absolute bottom-4 left-8 h-16 w-16 -rotate-45 text-primary/5" />
          <input
            ref={inputRef}
            type="file"
            accept=".csv"
            onChange={handleInputChange}
            className="hidden"
          />
          <div className="flex h-14 w-14 items-center justify-center rounded-2xl bg-primary/10">
            <Upload className="h-6 w-6 text-primary" />
          </div>
          <p className="mt-4 text-sm font-medium text-foreground">
            Drop your CSV file here, or click to browse
          </p>
          <p className="mt-1.5 text-xs text-muted-foreground">
            Accepts .csv files with required operational parameters
          </p>
        </div>

        {/* Required fields info */}
        <div className="mt-4 rounded-xl border border-border bg-card p-4">
          <p className="text-xs font-semibold uppercase tracking-wider text-muted-foreground">
            Required Parameters
          </p>
          <div className="mt-2 flex flex-wrap gap-2">
            {REQUIRED_FIELDS.map((field) => (
              <span
                key={field}
                className="rounded-md bg-secondary px-2.5 py-1 font-mono text-xs text-muted-foreground"
              >
                {field}
              </span>
            ))}
          </div>
        </div>

        {/* Error */}
        <AnimatePresence>
          {error && (
            <motion.div
              initial={{ opacity: 0, height: 0 }}
              animate={{ opacity: 1, height: "auto" }}
              exit={{ opacity: 0, height: 0 }}
              className="mt-4 flex items-center gap-2 rounded-xl border border-destructive/30 bg-destructive/10 p-4"
            >
              <AlertCircle className="h-4 w-4 shrink-0 text-destructive" />
              <p className="text-sm text-destructive">{error}</p>
              <button
                onClick={() => setError(null)}
                className="ml-auto text-destructive hover:text-destructive/80"
              >
                <X className="h-4 w-4" />
              </button>
            </motion.div>
          )}
        </AnimatePresence>

        {/* Success + Preview */}
        <AnimatePresence>
          {hasData && (
            <motion.div
              initial={{ opacity: 0, y: 12 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -12 }}
              transition={{ duration: 0.4 }}
              className="mt-6"
            >
              <div className="flex items-center gap-3 rounded-xl border border-primary/20 bg-primary/5 p-4">
                <CheckCircle2 className="h-5 w-5 text-primary" />
                <div>
                  <p className="text-sm font-medium text-foreground">
                    Data uploaded successfully
                  </p>
                  <p className="text-xs text-muted-foreground">
                    {fileName && <span>{fileName} - </span>}
                    {data.length} records loaded
                  </p>
                </div>
              </div>

              {/* Data preview table */}
              <div className="mt-4 overflow-hidden rounded-xl border border-border bg-card">
                <div className="flex items-center gap-2 border-b border-border px-4 py-3">
                  <FileSpreadsheet className="h-4 w-4 text-muted-foreground" />
                  <p className="text-sm font-medium text-foreground">
                    Data Preview
                  </p>
                  <span className="ml-auto rounded-md bg-secondary px-2 py-0.5 text-xs text-muted-foreground">
                    {data.length} rows
                  </span>
                </div>
                <div className="overflow-x-auto">
                  <table className="w-full text-left text-xs">
                    <thead>
                      <tr className="border-b border-border bg-secondary/50">
                        <th className="px-4 py-2.5 font-semibold text-muted-foreground">
                          #
                        </th>
                        {REQUIRED_FIELDS.map((f) => (
                          <th
                            key={f}
                            className="px-4 py-2.5 font-mono font-semibold text-muted-foreground"
                          >
                            {f}
                          </th>
                        ))}
                      </tr>
                    </thead>
                    <tbody>
                      {data.slice(0, 10).map((row, i) => (
                        <tr
                          key={i}
                          className="border-b border-border/50 last:border-0"
                        >
                          <td className="px-4 py-2 text-muted-foreground">
                            {i + 1}
                          </td>
                          <td className="px-4 py-2 font-mono text-foreground">
                            {row.energy_kwh}
                          </td>
                          <td className="px-4 py-2 font-mono text-foreground">
                            {row.operating_hours}
                          </td>
                          <td className="px-4 py-2 font-mono text-foreground">
                            {row.idle_percentage}
                          </td>
                          <td className="px-4 py-2 font-mono text-foreground">
                            {row.avg_temperature}
                          </td>
                          <td className="px-4 py-2 font-mono text-foreground">
                            {row.machine_noise_db}
                          </td>
                          <td className="px-4 py-2 font-mono text-foreground">
                            {row.production_units}
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
                {data.length > 10 && (
                  <div className="border-t border-border px-4 py-2 text-center text-xs text-muted-foreground">
                    Showing 10 of {data.length} records
                  </div>
                )}
              </div>

              <div className="mt-4 flex gap-3">
                <Button
                  variant="outline"
                  onClick={() => {
                    setData([])
                    setFileName(null)
                  }}
                  className="text-sm"
                >
                  Clear Data
                </Button>
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </motion.div>
    </AnimatedPage>
  )
}
