"use client"

import { useMemo, useState } from "react"
import {
  AreaChart,
  Area,
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  Cell,
  PieChart,
  Pie,
  Legend,
} from "recharts"
import { motion, AnimatePresence } from "framer-motion"
import { Brain, Flame, BarChart3, TrendingUp, AlertTriangle, Shield, ChevronDown, ChevronUp } from "lucide-react"
import { useCsvData, EMISSION_FACTOR } from "@/context/csv-data-context"
import { AnimatedPage } from "@/components/animated-page"
import { KpiCard } from "@/components/kpi-card"
import { NoDataWarning } from "@/components/no-data-warning"
import { cn } from "@/lib/utils"

const GREEN = "hsl(152 56% 48%)"
const AMBER = "hsl(38 92% 55%)"
const RED = "hsl(0 72% 51%)"
const BLUE = "hsl(200 65% 50%)"
const GRID = "hsl(150 6% 16%)"
const TICK = "hsl(150 8% 50%)"

function PredTooltip({
  active,
  payload,
  label,
}: {
  active?: boolean
  payload?: Array<{ value: number; name: string; color: string }>
  label?: string
}) {
  if (!active || !payload?.length) return null
  return (
    <div className="rounded-lg border border-border bg-card/95 px-3 py-2 shadow-xl backdrop-blur-sm">
      <p className="mb-1 text-[10px] font-semibold uppercase tracking-wider text-muted-foreground">
        Record {label}
      </p>
      {payload.map((entry) => (
        <p key={entry.name} className="text-xs font-semibold" style={{ color: entry.color }}>
          {entry.name}: {entry.value.toFixed(2)}
        </p>
      ))}
    </div>
  )
}

function RiskBadge({ level }: { level: string }) {
  const config: Record<string, { bg: string; text: string; dot: string }> = {
    low: { bg: "bg-emerald-500/10", text: "text-emerald-400", dot: "bg-emerald-400" },
    moderate: { bg: "bg-amber-500/10", text: "text-amber-400", dot: "bg-amber-400" },
    high: { bg: "bg-orange-500/10", text: "text-orange-400", dot: "bg-orange-400" },
    critical: { bg: "bg-red-500/10", text: "text-red-400", dot: "bg-red-400" },
  }
  const c = config[level] || config.low
  return (
    <span className={cn("inline-flex items-center gap-1.5 rounded-full px-2.5 py-1 text-xs font-semibold", c.bg, c.text)}>
      <span className={cn("h-1.5 w-1.5 rounded-full", c.dot)} />
      {level.charAt(0).toUpperCase() + level.slice(1)} Risk
    </span>
  )
}

function EmissionBar({ value, max }: { value: number; max: number }) {
  const pct = Math.min((value / max) * 100, 100)
  const color = pct > 80 ? RED : pct > 50 ? AMBER : GREEN
  return (
    <div className="flex items-center gap-2">
      <div className="h-1.5 flex-1 overflow-hidden rounded-full bg-secondary">
        <div className="h-full rounded-full" style={{ width: `${pct}%`, backgroundColor: color }} />
      </div>
      <span className="w-12 text-right font-mono text-[10px]" style={{ color }}>{value.toFixed(1)}</span>
    </div>
  )
}

export default function PredictionPage() {
  const { data, hasData, analytics } = useCsvData()
  const [showAllRecords, setShowAllRecords] = useState(false)

  const predictions = useMemo(() => {
    if (!hasData || !analytics) return null
    const perRecord = data.map((r, i) => {
      const emission = +(r.energy_kwh * EMISSION_FACTOR).toFixed(2)
      const threshold = analytics.avgEnergy * EMISSION_FACTOR + 1.5 * analytics.energyStdDev * EMISSION_FACTOR
      return {
        index: i + 1,
        emission,
        energy: r.energy_kwh,
        temperature: r.avg_temperature,
        isAnomaly: emission > threshold,
        riskScore: Math.min(100, +(
          (r.energy_kwh / analytics.peakEnergy) * 40 +
          (r.avg_temperature / 120) * 30 +
          (r.idle_percentage / 100) * 30
        ).toFixed(1)),
      }
    })

    // Distribution buckets
    const maxEmission = Math.max(...perRecord.map((r) => r.emission))
    const bucketSize = maxEmission / 6
    const distribution = Array.from({ length: 6 }, (_, i) => {
      const min = bucketSize * i
      const max = bucketSize * (i + 1)
      const count = perRecord.filter((r) => r.emission >= min && r.emission < (i === 5 ? Infinity : max)).length
      return { range: `${min.toFixed(0)}-${max.toFixed(0)}`, count, min, max: max }
    })

    // Risk pie data
    const lowRisk = perRecord.filter((r) => r.riskScore < 40).length
    const medRisk = perRecord.filter((r) => r.riskScore >= 40 && r.riskScore < 70).length
    const highRisk = perRecord.filter((r) => r.riskScore >= 70).length

    return { perRecord, distribution, riskPie: [
      { name: "Low Risk", value: lowRisk, color: GREEN },
      { name: "Medium Risk", value: medRisk, color: AMBER },
      { name: "High Risk", value: highRisk, color: RED },
    ]}
  }, [data, hasData, analytics])

  if (!hasData || !analytics || !predictions) {
    return (
      <AnimatedPage>
        <div className="flex items-center gap-3">
          <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-primary/10">
            <Brain className="h-5 w-5 text-primary" />
          </div>
          <div>
            <h1 className="text-2xl font-bold text-foreground">AI Emission Prediction</h1>
            <p className="text-sm text-muted-foreground">ML-based carbon emission analysis</p>
          </div>
        </div>
        <NoDataWarning />
      </AnimatedPage>
    )
  }

  const anomalyCount = predictions.perRecord.filter((r) => r.isAnomaly).length
  const visibleRecords = showAllRecords ? predictions.perRecord : predictions.perRecord.slice(0, 20)
  const maxEmissionVal = Math.max(...predictions.perRecord.map((r) => r.emission))

  return (
    <AnimatedPage>
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-primary/10">
            <Brain className="h-5 w-5 text-primary" />
          </div>
          <div>
            <h1 className="text-2xl font-bold text-foreground">AI Emission Prediction</h1>
            <p className="text-sm text-muted-foreground">
              Predictive analysis across {analytics.totalRecords} operational records
            </p>
          </div>
        </div>
        <RiskBadge level={analytics.riskLevel} />
      </div>

      {/* KPI Cards */}
      <div className="mt-6 grid gap-4 md:grid-cols-2 lg:grid-cols-4">
        <KpiCard
          title="Total Predicted CO2"
          value={`${analytics.totalEmission.toFixed(1)} kg`}
          subtitle="Aggregate emission forecast"
          icon={Flame}
          delay={0.1}
        />
        <KpiCard
          title="Carbon Intensity"
          value={analytics.carbonIntensity.toFixed(4)}
          subtitle="kg CO2 / production unit"
          icon={BarChart3}
          delay={0.15}
        />
        <KpiCard
          title="Avg per Record"
          value={`${analytics.avgEmission.toFixed(2)} kg`}
          subtitle="Mean predicted emission"
          icon={TrendingUp}
          delay={0.2}
        />
        <KpiCard
          title="Efficiency Grade"
          value={analytics.efficiencyGrade}
          subtitle={`${analytics.avgEfficiency.toFixed(1)}% operational efficiency`}
          icon={Shield}
          delay={0.25}
        />
      </div>

      {/* Emission Area Chart */}
      <motion.div
        initial={{ opacity: 0, y: 16 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5, delay: 0.3 }}
        className="mt-6 rounded-xl border border-border bg-card p-5"
      >
        <div className="mb-4 flex items-center justify-between">
          <div>
            <h3 className="text-sm font-semibold text-foreground">Emission Prediction Curve</h3>
            <p className="text-xs text-muted-foreground">
              CO2 prediction per record with anomaly highlights
            </p>
          </div>
          {anomalyCount > 0 && (
            <div className="flex items-center gap-1.5 text-xs text-destructive">
              <AlertTriangle className="h-3.5 w-3.5" />
              {anomalyCount} anomalies
            </div>
          )}
        </div>
        <ResponsiveContainer width="100%" height={300}>
          <AreaChart data={predictions.perRecord}>
            <defs>
              <linearGradient id="emissionGrad" x1="0" y1="0" x2="0" y2="1">
                <stop offset="0%" stopColor={GREEN} stopOpacity={0.25} />
                <stop offset="100%" stopColor={GREEN} stopOpacity={0} />
              </linearGradient>
            </defs>
            <CartesianGrid strokeDasharray="3 3" stroke={GRID} />
            <XAxis dataKey="index" tick={{ fontSize: 10, fill: TICK }} axisLine={{ stroke: GRID }} tickLine={false} />
            <YAxis tick={{ fontSize: 10, fill: TICK }} axisLine={{ stroke: GRID }} tickLine={false} />
            <Tooltip content={<PredTooltip />} />
            <Area type="monotone" dataKey="emission" name="CO2 (kg)" stroke={GREEN} strokeWidth={2} fill="url(#emissionGrad)" dot={false} activeDot={{ r: 4, fill: GREEN, stroke: "hsl(150 8% 6%)", strokeWidth: 2 }} />
          </AreaChart>
        </ResponsiveContainer>
      </motion.div>

      <div className="mt-6 grid gap-6 lg:grid-cols-2">
        {/* Emission Distribution */}
        <motion.div
          initial={{ opacity: 0, y: 16 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5, delay: 0.35 }}
          className="rounded-xl border border-border bg-card p-5"
        >
          <h3 className="text-sm font-semibold text-foreground">Emission Distribution</h3>
          <p className="mb-4 text-xs text-muted-foreground">Frequency of CO2 emission ranges (kg)</p>
          <ResponsiveContainer width="100%" height={240}>
            <BarChart data={predictions.distribution}>
              <CartesianGrid strokeDasharray="3 3" stroke={GRID} />
              <XAxis dataKey="range" tick={{ fontSize: 9, fill: TICK }} axisLine={{ stroke: GRID }} tickLine={false} />
              <YAxis tick={{ fontSize: 10, fill: TICK }} axisLine={{ stroke: GRID }} tickLine={false} />
              <Tooltip content={<PredTooltip />} />
              <Bar dataKey="count" name="Records" radius={[4, 4, 0, 0]}>
                {predictions.distribution.map((_, i) => (
                  <Cell key={i} fill={i < 2 ? GREEN : i < 4 ? AMBER : RED} fillOpacity={0.8} />
                ))}
              </Bar>
            </BarChart>
          </ResponsiveContainer>
        </motion.div>

        {/* Risk Breakdown Pie */}
        <motion.div
          initial={{ opacity: 0, y: 16 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5, delay: 0.4 }}
          className="rounded-xl border border-border bg-card p-5"
        >
          <h3 className="text-sm font-semibold text-foreground">Risk Breakdown</h3>
          <p className="mb-2 text-xs text-muted-foreground">Record distribution by risk score</p>
          <ResponsiveContainer width="100%" height={240}>
            <PieChart>
              <Pie
                data={predictions.riskPie}
                cx="50%"
                cy="50%"
                innerRadius={55}
                outerRadius={85}
                paddingAngle={3}
                dataKey="value"
                strokeWidth={0}
              >
                {predictions.riskPie.map((entry, i) => (
                  <Cell key={i} fill={entry.color} />
                ))}
              </Pie>
              <Legend
                formatter={(value: string) => <span className="text-xs text-muted-foreground">{value}</span>}
              />
              <Tooltip
                content={({ active, payload }) => {
                  if (!active || !payload?.length) return null
                  const item = payload[0]
                  return (
                    <div className="rounded-lg border border-border bg-card/95 px-3 py-2 shadow-xl backdrop-blur-sm">
                      <p className="text-xs font-semibold" style={{ color: item.payload.color }}>
                        {item.name}: {item.value} records
                      </p>
                    </div>
                  )
                }}
              />
            </PieChart>
          </ResponsiveContainer>
        </motion.div>
      </div>

      {/* Per-record Prediction Table with heatmap bars */}
      <motion.div
        initial={{ opacity: 0, y: 16 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5, delay: 0.45 }}
        className="mt-6 overflow-hidden rounded-xl border border-border bg-card"
      >
        <div className="flex items-center justify-between border-b border-border px-5 py-3">
          <div>
            <h3 className="text-sm font-semibold text-foreground">Per-Record Predictions</h3>
            <p className="text-xs text-muted-foreground">Emission forecast with risk heatmap</p>
          </div>
          <span className="text-xs text-muted-foreground">
            {predictions.perRecord.length} records
          </span>
        </div>
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead>
              <tr className="border-b border-border bg-secondary/30">
                <th className="px-5 py-2.5 font-semibold text-muted-foreground">#</th>
                <th className="px-5 py-2.5 font-semibold text-muted-foreground">Energy (kWh)</th>
                <th className="px-5 py-2.5 font-semibold text-muted-foreground">Temp</th>
                <th className="w-48 px-5 py-2.5 font-semibold text-muted-foreground">CO2 Emission</th>
                <th className="px-5 py-2.5 font-semibold text-muted-foreground">Risk</th>
                <th className="px-5 py-2.5 font-semibold text-muted-foreground">Status</th>
              </tr>
            </thead>
            <tbody>
              <AnimatePresence>
                {visibleRecords.map((r) => (
                  <motion.tr
                    key={r.index}
                    initial={{ opacity: 0 }}
                    animate={{ opacity: 1 }}
                    className={cn(
                      "border-b border-border/30 last:border-0",
                      r.isAnomaly && "bg-destructive/[0.03]"
                    )}
                  >
                    <td className="px-5 py-2 font-mono text-muted-foreground">{r.index}</td>
                    <td className="px-5 py-2 font-mono text-foreground">{r.energy.toFixed(1)}</td>
                    <td className="px-5 py-2 font-mono text-foreground">{r.temperature.toFixed(1)}</td>
                    <td className="px-5 py-2">
                      <EmissionBar value={r.emission} max={maxEmissionVal} />
                    </td>
                    <td className="px-5 py-2">
                      <span
                        className="font-mono text-[10px] font-semibold"
                        style={{ color: r.riskScore >= 70 ? RED : r.riskScore >= 40 ? AMBER : GREEN }}
                      >
                        {r.riskScore}
                      </span>
                    </td>
                    <td className="px-5 py-2">
                      {r.isAnomaly ? (
                        <span className="inline-flex items-center gap-1 rounded bg-destructive/10 px-1.5 py-0.5 text-[10px] font-semibold text-destructive">
                          <AlertTriangle className="h-2.5 w-2.5" />
                          Anomaly
                        </span>
                      ) : (
                        <span className="text-[10px] text-muted-foreground">Normal</span>
                      )}
                    </td>
                  </motion.tr>
                ))}
              </AnimatePresence>
            </tbody>
          </table>
        </div>
        {predictions.perRecord.length > 20 && (
          <button
            onClick={() => setShowAllRecords(!showAllRecords)}
            className="flex w-full items-center justify-center gap-1.5 border-t border-border px-5 py-2.5 text-xs font-medium text-primary transition-colors hover:bg-secondary/30"
          >
            {showAllRecords ? (
              <>Show Less <ChevronUp className="h-3 w-3" /></>
            ) : (
              <>Show all {predictions.perRecord.length} records <ChevronDown className="h-3 w-3" /></>
            )}
          </button>
        )}
      </motion.div>
    </AnimatedPage>
  )
}
