"use client"

import { useMemo, useState, useEffect } from "react"
import {
  BarChart,
  Bar,
  AreaChart,
  Area,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  Legend,
  RadarChart,
  Radar,
  PolarGrid,
  PolarAngleAxis,
  PolarRadiusAxis,
} from "recharts"
import { motion, AnimatePresence } from "framer-motion"
import {
  Zap,
  TrendingDown,
  ArrowDownRight,
  CheckCircle2,
  Loader2,
  Thermometer,
  Activity,
  Gauge,
  Flame,
} from "lucide-react"
import { useCsvData, EMISSION_FACTOR } from "@/context/csv-data-context"
import { AnimatedPage } from "@/components/animated-page"
import { NoDataWarning } from "@/components/no-data-warning"
import { Button } from "@/components/ui/button"
import { cn } from "@/lib/utils"

const GREEN = "hsl(152 56% 48%)"
const AMBER = "hsl(38 92% 55%)"
const RED = "hsl(0 72% 51%)"
const BLUE = "hsl(200 65% 50%)"
const GRID = "hsl(150 6% 16%)"
const TICK = "hsl(150 8% 50%)"
const MUTED_BAR = "hsl(150 6% 22%)"

const PHASES = [
  { label: "Analyzing operational data...", duration: 800 },
  { label: "Running energy reduction model...", duration: 900 },
  { label: "Optimizing thermal parameters...", duration: 700 },
  { label: "Reducing idle time allocation...", duration: 600 },
  { label: "Computing emission projections...", duration: 500 },
  { label: "Generating report...", duration: 400 },
]

function OptTooltip({
  active,
  payload,
  label,
}: {
  active?: boolean
  payload?: Array<{ value: number; name: string; color: string }>
  label?: string
}) {
  if (!active || !payload?.length) return null
  return (
    <div className="rounded-lg border border-border bg-card/95 px-3 py-2 shadow-xl backdrop-blur-sm">
      <p className="mb-1 text-[10px] font-semibold uppercase tracking-wider text-muted-foreground">
        {label}
      </p>
      {payload.map((entry) => (
        <p key={entry.name} className="text-xs font-semibold" style={{ color: entry.color }}>
          {entry.name}: {typeof entry.value === "number" ? entry.value.toFixed(2) : entry.value}
        </p>
      ))}
    </div>
  )
}

function MetricDelta({
  label,
  before,
  after,
  unit,
  icon: Icon,
  delay,
}: {
  label: string
  before: number
  after: number
  unit: string
  icon: typeof Zap
  delay: number
}) {
  const delta = before - after
  const deltaPct = before > 0 ? (delta / before) * 100 : 0

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5, delay }}
      className="group relative overflow-hidden rounded-xl border border-border bg-card p-5"
    >
      <div className="absolute inset-0 bg-gradient-to-br from-primary/[0.03] to-transparent opacity-0 transition-opacity group-hover:opacity-100" />
      <div className="relative">
        <div className="flex items-center justify-between">
          <p className="text-[11px] font-semibold uppercase tracking-wider text-muted-foreground">
            {label}
          </p>
          <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-primary/10">
            <Icon className="h-4 w-4 text-primary" />
          </div>
        </div>
        <div className="mt-3 flex items-end gap-4">
          <div>
            <p className="text-[10px] text-muted-foreground">Before</p>
            <p className="text-lg font-bold text-foreground">{before.toFixed(1)}</p>
          </div>
          <TrendingDown className="mb-1.5 h-4 w-4 text-primary" />
          <div>
            <p className="text-[10px] text-muted-foreground">After</p>
            <p className="text-lg font-bold text-primary">{after.toFixed(1)}</p>
          </div>
          <div className="ml-auto text-right">
            <p className="text-[10px] text-muted-foreground">Saved</p>
            <p className="font-mono text-sm font-bold text-primary">
              -{deltaPct.toFixed(1)}%
            </p>
          </div>
        </div>
        <p className="mt-1 text-[10px] text-muted-foreground">
          {delta.toFixed(1)} {unit} reduction
        </p>
      </div>
    </motion.div>
  )
}

export default function OptimizationPage() {
  const { data, hasData, analytics, optimizedData, optimizedAnalytics, runOptimization, isOptimized } = useCsvData()
  const [isRunning, setIsRunning] = useState(false)
  const [currentPhase, setCurrentPhase] = useState(-1)

  const handleOptimize = () => {
    setIsRunning(true)
    setCurrentPhase(0)
  }

  useEffect(() => {
    if (!isRunning || currentPhase < 0) return
    if (currentPhase >= PHASES.length) {
      runOptimization()
      setIsRunning(false)
      setCurrentPhase(-1)
      return
    }
    const timer = setTimeout(() => {
      setCurrentPhase((p) => p + 1)
    }, PHASES[currentPhase].duration)
    return () => clearTimeout(timer)
  }, [isRunning, currentPhase, runOptimization])

  const comparisonData = useMemo(() => {
    if (!hasData || !optimizedData) return []
    return data.slice(0, 30).map((r, i) => ({
      index: i + 1,
      before: +(r.energy_kwh * EMISSION_FACTOR).toFixed(2),
      after: +(optimizedData[i].energy_kwh * EMISSION_FACTOR).toFixed(2),
    }))
  }, [data, hasData, optimizedData])

  const radarComparison = useMemo(() => {
    if (!analytics || !optimizedAnalytics) return []
    return [
      { metric: "Energy", before: (analytics.avgEnergy / analytics.peakEnergy) * 100, after: (optimizedAnalytics.avgEnergy / analytics.peakEnergy) * 100 },
      { metric: "Emission", before: (analytics.avgEmission / analytics.peakEmission) * 100, after: (optimizedAnalytics.avgEmission / analytics.peakEmission) * 100 },
      { metric: "Temp", before: Math.min((analytics.avgTemperature / 120) * 100, 100), after: Math.min((optimizedAnalytics.avgTemperature / 120) * 100, 100) },
      { metric: "Efficiency", before: analytics.avgEfficiency, after: optimizedAnalytics.avgEfficiency },
      { metric: "Idle", before: analytics.avgIdlePercent, after: optimizedAnalytics.avgIdlePercent },
    ]
  }, [analytics, optimizedAnalytics])

  const deltaChartData = useMemo(() => {
    if (!analytics || !optimizedAnalytics) return []
    return [
      { name: "CO2 (kg)", before: +analytics.totalEmission.toFixed(0), after: +optimizedAnalytics.totalEmission.toFixed(0) },
      { name: "Energy (kWh)", before: +analytics.totalEnergy.toFixed(0), after: +optimizedAnalytics.totalEnergy.toFixed(0) },
    ]
  }, [analytics, optimizedAnalytics])

  if (!hasData) {
    return (
      <AnimatedPage>
        <div className="flex items-center gap-3">
          <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-primary/10">
            <Zap className="h-5 w-5 text-primary" />
          </div>
          <div>
            <h1 className="text-2xl font-bold text-foreground">AI Optimization</h1>
            <p className="text-sm text-muted-foreground">Closed-loop emission reduction engine</p>
          </div>
        </div>
        <NoDataWarning />
      </AnimatedPage>
    )
  }

  return (
    <AnimatedPage>
      <div className="flex items-center gap-3">
        <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-primary/10">
          <Zap className="h-5 w-5 text-primary" />
        </div>
        <div>
          <h1 className="text-2xl font-bold text-foreground">AI Optimization</h1>
          <p className="text-sm text-muted-foreground">
            Simulated 12% energy + 10% idle + 5% thermal reduction across {analytics?.totalRecords} records
          </p>
        </div>
      </div>

      {/* Optimization Engine Card */}
      <motion.div
        initial={{ opacity: 0, y: 16 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5, delay: 0.1 }}
        className="mt-6 overflow-hidden rounded-xl border border-border bg-card"
      >
        <div className="flex flex-col gap-4 p-6 md:flex-row md:items-center md:justify-between">
          <div>
            <h3 className="text-sm font-semibold text-foreground">Optimization Engine</h3>
            <p className="mt-1 text-xs leading-relaxed text-muted-foreground">
              AI-driven parameter optimization: energy consumption (-12%), thermal output (-5%), and idle time (-10 pts).
              The engine recalculates all emission forecasts with optimized parameters.
            </p>
          </div>
          <Button
            onClick={handleOptimize}
            disabled={isOptimized || isRunning}
            className="shrink-0 gap-2"
            size="lg"
          >
            {isOptimized ? (
              <>
                <CheckCircle2 className="h-4 w-4" />
                Optimization Complete
              </>
            ) : isRunning ? (
              <>
                <Loader2 className="h-4 w-4 animate-spin" />
                Running...
              </>
            ) : (
              <>
                <Zap className="h-4 w-4" />
                Run AI Optimization
              </>
            )}
          </Button>
        </div>

        {/* Phase progress */}
        <AnimatePresence>
          {isRunning && currentPhase >= 0 && currentPhase < PHASES.length && (
            <motion.div
              initial={{ height: 0, opacity: 0 }}
              animate={{ height: "auto", opacity: 1 }}
              exit={{ height: 0, opacity: 0 }}
              className="border-t border-border"
            >
              <div className="p-4">
                <div className="mb-3 flex items-center justify-between">
                  <p className="text-xs font-medium text-foreground">{PHASES[currentPhase].label}</p>
                  <span className="font-mono text-[10px] text-muted-foreground">
                    {currentPhase + 1}/{PHASES.length}
                  </span>
                </div>
                <div className="h-1.5 overflow-hidden rounded-full bg-secondary">
                  <motion.div
                    className="h-full rounded-full bg-primary"
                    initial={{ width: `${(currentPhase / PHASES.length) * 100}%` }}
                    animate={{ width: `${((currentPhase + 1) / PHASES.length) * 100}%` }}
                    transition={{ duration: 0.5 }}
                  />
                </div>
                <div className="mt-3 flex flex-wrap gap-2">
                  {PHASES.map((phase, i) => (
                    <span
                      key={i}
                      className={cn(
                        "rounded px-2 py-0.5 text-[10px] font-medium transition-colors",
                        i < currentPhase
                          ? "bg-primary/10 text-primary"
                          : i === currentPhase
                            ? "bg-primary/20 text-primary"
                            : "bg-secondary text-muted-foreground"
                      )}
                    >
                      {phase.label.replace("...", "")}
                    </span>
                  ))}
                </div>
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </motion.div>

      {/* Results */}
      <AnimatePresence>
        {isOptimized && analytics && optimizedAnalytics && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ duration: 0.6 }}
          >
            {/* Big Reduction Hero */}
            <motion.div
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ duration: 0.5, delay: 0.1 }}
              className="mt-6 rounded-xl border border-primary/20 bg-gradient-to-br from-primary/5 to-transparent p-8 text-center"
            >
              <div className="flex items-center justify-center gap-3">
                <ArrowDownRight className="h-8 w-8 text-primary" />
                <span className="text-5xl font-bold tracking-tight text-primary">
                  {(((analytics.totalEmission - optimizedAnalytics.totalEmission) / analytics.totalEmission) * 100).toFixed(1)}%
                </span>
              </div>
              <p className="mt-2 text-sm text-muted-foreground">Total emission reduction achieved</p>
              <div className="mx-auto mt-4 flex max-w-md items-center justify-center gap-8">
                <div>
                  <p className="text-xs text-muted-foreground">Before</p>
                  <p className="font-mono text-lg font-bold text-foreground">{analytics.totalEmission.toFixed(0)} kg</p>
                </div>
                <div className="h-8 w-px bg-border" />
                <div>
                  <p className="text-xs text-muted-foreground">After</p>
                  <p className="font-mono text-lg font-bold text-primary">{optimizedAnalytics.totalEmission.toFixed(0)} kg</p>
                </div>
                <div className="h-8 w-px bg-border" />
                <div>
                  <p className="text-xs text-muted-foreground">Saved</p>
                  <p className="font-mono text-lg font-bold text-primary">
                    {(analytics.totalEmission - optimizedAnalytics.totalEmission).toFixed(0)} kg
                  </p>
                </div>
              </div>
            </motion.div>

            {/* Delta Metrics */}
            <div className="mt-6 grid gap-4 md:grid-cols-2 lg:grid-cols-4">
              <MetricDelta label="CO2 Emission" before={analytics.totalEmission} after={optimizedAnalytics.totalEmission} unit="kg" icon={Flame} delay={0.15} />
              <MetricDelta label="Energy" before={analytics.totalEnergy} after={optimizedAnalytics.totalEnergy} unit="kWh" icon={Zap} delay={0.2} />
              <MetricDelta label="Avg Temperature" before={analytics.avgTemperature} after={optimizedAnalytics.avgTemperature} unit="C" icon={Thermometer} delay={0.25} />
              <MetricDelta label="Avg Idle %" before={analytics.avgIdlePercent} after={optimizedAnalytics.avgIdlePercent} unit="pts" icon={Gauge} delay={0.3} />
            </div>

            <div className="mt-6 grid gap-6 lg:grid-cols-2">
              {/* Before vs After Bar Chart */}
              <motion.div
                initial={{ opacity: 0, y: 16 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.5, delay: 0.35 }}
                className="rounded-xl border border-border bg-card p-5"
              >
                <h3 className="text-sm font-semibold text-foreground">Emission: Before vs After</h3>
                <p className="mb-4 text-xs text-muted-foreground">CO2 per record comparison (first 30)</p>
                <ResponsiveContainer width="100%" height={280}>
                  <BarChart data={comparisonData} barGap={2}>
                    <CartesianGrid strokeDasharray="3 3" stroke={GRID} />
                    <XAxis dataKey="index" tick={{ fontSize: 9, fill: TICK }} axisLine={{ stroke: GRID }} tickLine={false} />
                    <YAxis tick={{ fontSize: 10, fill: TICK }} axisLine={{ stroke: GRID }} tickLine={false} />
                    <Tooltip content={<OptTooltip />} />
                    <Legend wrapperStyle={{ fontSize: 11, color: TICK }} />
                    <Bar dataKey="before" name="Before" fill={MUTED_BAR} radius={[3, 3, 0, 0]} />
                    <Bar dataKey="after" name="After" fill={GREEN} radius={[3, 3, 0, 0]} />
                  </BarChart>
                </ResponsiveContainer>
              </motion.div>

              {/* Radar Comparison */}
              <motion.div
                initial={{ opacity: 0, y: 16 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.5, delay: 0.4 }}
                className="rounded-xl border border-border bg-card p-5"
              >
                <h3 className="text-sm font-semibold text-foreground">Optimization Radar</h3>
                <p className="mb-2 text-xs text-muted-foreground">Before vs after normalized profile</p>
                <ResponsiveContainer width="100%" height={280}>
                  <RadarChart data={radarComparison} cx="50%" cy="50%" outerRadius="65%">
                    <PolarGrid stroke={GRID} />
                    <PolarAngleAxis dataKey="metric" tick={{ fontSize: 10, fill: TICK }} />
                    <PolarRadiusAxis tick={false} axisLine={false} />
                    <Radar name="Before" dataKey="before" stroke={MUTED_BAR} fill={MUTED_BAR} fillOpacity={0.15} strokeWidth={1.5} />
                    <Radar name="After" dataKey="after" stroke={GREEN} fill={GREEN} fillOpacity={0.15} strokeWidth={2} />
                    <Legend wrapperStyle={{ fontSize: 11, color: TICK }} />
                  </RadarChart>
                </ResponsiveContainer>
              </motion.div>
            </div>

            {/* Cumulative Savings Area Chart */}
            <motion.div
              initial={{ opacity: 0, y: 16 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: 0.45 }}
              className="mt-6 rounded-xl border border-border bg-card p-5"
            >
              <h3 className="text-sm font-semibold text-foreground">Cumulative Savings Curve</h3>
              <p className="mb-4 text-xs text-muted-foreground">CO2 savings accumulating across records</p>
              <ResponsiveContainer width="100%" height={260}>
                <AreaChart
                  data={comparisonData.map((r, i, arr) => ({
                    index: r.index,
                    savings: arr.slice(0, i + 1).reduce((s, v) => s + (v.before - v.after), 0),
                  }))}
                >
                  <defs>
                    <linearGradient id="savingsGrad" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="0%" stopColor={GREEN} stopOpacity={0.25} />
                      <stop offset="100%" stopColor={GREEN} stopOpacity={0} />
                    </linearGradient>
                  </defs>
                  <CartesianGrid strokeDasharray="3 3" stroke={GRID} />
                  <XAxis dataKey="index" tick={{ fontSize: 10, fill: TICK }} axisLine={{ stroke: GRID }} tickLine={false} />
                  <YAxis tick={{ fontSize: 10, fill: TICK }} axisLine={{ stroke: GRID }} tickLine={false} />
                  <Tooltip content={<OptTooltip />} />
                  <Area type="monotone" dataKey="savings" name="Cumulative CO2 Saved (kg)" stroke={GREEN} strokeWidth={2} fill="url(#savingsGrad)" dot={false} />
                </AreaChart>
              </ResponsiveContainer>
            </motion.div>

            {/* Summary Stats Table */}
            <motion.div
              initial={{ opacity: 0, y: 16 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: 0.5 }}
              className="mt-6 overflow-hidden rounded-xl border border-border bg-card"
            >
              <div className="border-b border-border px-5 py-3">
                <h3 className="text-sm font-semibold text-foreground">Optimization Summary</h3>
              </div>
              <div className="overflow-x-auto">
                <table className="w-full text-left text-xs">
                  <thead>
                    <tr className="border-b border-border bg-secondary/30">
                      <th className="px-5 py-2.5 font-semibold text-muted-foreground">Parameter</th>
                      <th className="px-5 py-2.5 font-semibold text-muted-foreground">Before</th>
                      <th className="px-5 py-2.5 font-semibold text-muted-foreground">After</th>
                      <th className="px-5 py-2.5 font-semibold text-muted-foreground">Change</th>
                      <th className="px-5 py-2.5 font-semibold text-muted-foreground">Grade</th>
                    </tr>
                  </thead>
                  <tbody>
                    {[
                      { param: "Total CO2 Emission", bv: `${analytics.totalEmission.toFixed(1)} kg`, av: `${optimizedAnalytics.totalEmission.toFixed(1)} kg`, delta: -(((analytics.totalEmission - optimizedAnalytics.totalEmission) / analytics.totalEmission) * 100) },
                      { param: "Total Energy", bv: `${analytics.totalEnergy.toFixed(0)} kWh`, av: `${optimizedAnalytics.totalEnergy.toFixed(0)} kWh`, delta: -(((analytics.totalEnergy - optimizedAnalytics.totalEnergy) / analytics.totalEnergy) * 100) },
                      { param: "Avg Temperature", bv: `${analytics.avgTemperature.toFixed(1)} C`, av: `${optimizedAnalytics.avgTemperature.toFixed(1)} C`, delta: -(((analytics.avgTemperature - optimizedAnalytics.avgTemperature) / analytics.avgTemperature) * 100) },
                      { param: "Avg Idle %", bv: `${analytics.avgIdlePercent.toFixed(1)}%`, av: `${optimizedAnalytics.avgIdlePercent.toFixed(1)}%`, delta: -(((analytics.avgIdlePercent - optimizedAnalytics.avgIdlePercent) / analytics.avgIdlePercent) * 100) },
                      { param: "Efficiency Grade", bv: analytics.efficiencyGrade, av: optimizedAnalytics.efficiencyGrade, delta: 0 },
                      { param: "Anomalies", bv: `${analytics.anomalyIndices.length}`, av: `${optimizedAnalytics.anomalyIndices.length}`, delta: -(((analytics.anomalyIndices.length - optimizedAnalytics.anomalyIndices.length) / Math.max(analytics.anomalyIndices.length, 1)) * 100) },
                    ].map((row) => (
                      <tr key={row.param} className="border-b border-border/30 last:border-0">
                        <td className="px-5 py-2.5 text-foreground">{row.param}</td>
                        <td className="px-5 py-2.5 font-mono text-foreground">{row.bv}</td>
                        <td className="px-5 py-2.5 font-mono text-primary">{row.av}</td>
                        <td className="px-5 py-2.5">
                          {row.delta !== 0 ? (
                            <span className="font-mono text-[10px] font-semibold text-primary">
                              {row.delta.toFixed(1)}%
                            </span>
                          ) : (
                            <span className="text-[10px] text-muted-foreground">--</span>
                          )}
                        </td>
                        <td className="px-5 py-2.5">
                          {row.param === "Efficiency Grade" ? (
                            <span className="rounded bg-primary/10 px-1.5 py-0.5 text-[10px] font-semibold text-primary">
                              {optimizedAnalytics.efficiencyGrade}
                            </span>
                          ) : (
                            <span className="text-[10px] text-muted-foreground">
                              {Math.abs(row.delta) > 10 ? "Significant" : Math.abs(row.delta) > 5 ? "Moderate" : "Minimal"}
                            </span>
                          )}
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </AnimatedPage>
  )
}
