"use client"

import Link from "next/link"
import Image from "next/image"
import { motion } from "framer-motion"
import { ArrowRight, Leaf, BarChart3, Cpu, Shield, Wind, Factory } from "lucide-react"
import { Button } from "@/components/ui/button"

const features = [
  {
    icon: Cpu,
    title: "AI-Powered Analysis",
    description:
      "Predict carbon emissions using indirect operational signals with advanced machine learning models.",
  },
  {
    icon: BarChart3,
    title: "Real-Time Monitoring",
    description:
      "Track energy patterns, thermal indicators, and acoustic load proxies with live signal visualization.",
  },
  {
    icon: Shield,
    title: "Closed-Loop Optimization",
    description:
      "Simulate efficiency improvements and quantify emission reductions with actionable recommendations.",
  },
]

const stats = [
  { label: "CO2 Tracked", value: "12K+ tons", icon: Wind },
  { label: "Industries", value: "50+", icon: Factory },
  { label: "Accuracy", value: "96.3%", icon: Cpu },
]

export default function WelcomePage() {
  return (
    <div className="relative flex min-h-screen flex-col items-center overflow-hidden bg-background">
      {/* Background image with overlay */}
      <div className="absolute inset-0">
        <Image
          src="/images/hero-bg.jpg"
          alt=""
          fill
          className="object-cover opacity-30"
          priority
        />
        <div className="absolute inset-0 bg-gradient-to-b from-background/60 via-background/80 to-background" />
      </div>

      {/* Grid overlay */}
      <div className="pointer-events-none absolute inset-0 bg-[linear-gradient(to_right,hsl(var(--border))_1px,transparent_1px),linear-gradient(to_bottom,hsl(var(--border))_1px,transparent_1px)] bg-[size:80px_80px] opacity-20" />

      {/* Radial glow */}
      <div className="pointer-events-none absolute left-1/2 top-1/4 h-[600px] w-[600px] -translate-x-1/2 -translate-y-1/2 rounded-full bg-primary/8 blur-[120px]" />

      {/* Top nav bar */}
      <motion.header
        initial={{ opacity: 0, y: -12 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5 }}
        className="relative z-10 flex w-full items-center justify-between px-6 py-4 md:px-12"
      >
        <div className="flex items-center gap-2">
          <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-primary">
            <Leaf className="h-4 w-4 text-primary-foreground" />
          </div>
          <span className="text-lg font-bold tracking-tight text-foreground">
            CarbonIQ
          </span>
        </div>
        <Button asChild variant="outline" size="sm" className="border-border/50 text-foreground hover:bg-secondary">
          <Link href="/dashboard">Dashboard</Link>
        </Button>
      </motion.header>

      {/* Hero section */}
      <main className="relative z-10 flex max-w-5xl flex-1 flex-col items-center justify-center px-6 text-center">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, ease: "easeOut" }}
          className="flex items-center gap-2 rounded-full border border-primary/20 bg-primary/5 px-4 py-1.5 backdrop-blur-sm"
        >
          <Leaf className="h-4 w-4 text-primary" />
          <span className="text-sm font-medium text-primary">
            Industrial Carbon Intelligence
          </span>
        </motion.div>

        <motion.h1
          initial={{ opacity: 0, y: 24 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.7, delay: 0.1, ease: "easeOut" }}
          className="mt-8 text-balance text-5xl font-bold leading-tight tracking-tight text-foreground md:text-7xl"
        >
          Carbon<span className="text-primary">IQ</span>
        </motion.h1>

        <motion.p
          initial={{ opacity: 0, y: 24 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.7, delay: 0.2, ease: "easeOut" }}
          className="mt-4 text-balance text-lg font-medium text-muted-foreground md:text-xl"
        >
          Decentralized AI Carbon Intelligence Platform
        </motion.p>

        <motion.p
          initial={{ opacity: 0, y: 24 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.7, delay: 0.3, ease: "easeOut" }}
          className="mt-3 max-w-2xl text-pretty text-sm leading-relaxed text-muted-foreground/80 md:text-base"
        >
          AI-based emission estimation using indirect operational signals.
          Monitor, predict, and optimize carbon footprint for small and
          mid-scale industries.
        </motion.p>

        <motion.div
          initial={{ opacity: 0, y: 24 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.7, delay: 0.4, ease: "easeOut" }}
          className="mt-10 flex items-center gap-4"
        >
          <Button asChild size="lg" className="gap-2 px-8 text-base font-semibold">
            <Link href="/dashboard">
              Enter Dashboard
              <ArrowRight className="h-4 w-4" />
            </Link>
          </Button>
          <Button asChild variant="outline" size="lg" className="border-border/50 text-foreground hover:bg-secondary">
            <Link href="/dashboard/upload">Upload Data</Link>
          </Button>
        </motion.div>

        {/* Stats row */}
        <motion.div
          initial={{ opacity: 0, y: 24 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.7, delay: 0.5, ease: "easeOut" }}
          className="mt-16 flex items-center gap-8 md:gap-12"
        >
          {stats.map((stat) => {
            const Icon = stat.icon
            return (
              <div key={stat.label} className="flex flex-col items-center gap-1.5">
                <Icon className="h-5 w-5 text-primary/70" />
                <p className="text-xl font-bold text-foreground md:text-2xl">{stat.value}</p>
                <p className="text-xs text-muted-foreground">{stat.label}</p>
              </div>
            )
          })}
        </motion.div>

        {/* Feature cards */}
        <motion.div
          initial={{ opacity: 0, y: 32 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 0.6, ease: "easeOut" }}
          className="mt-20 grid w-full gap-4 md:grid-cols-3"
        >
          {features.map((feature, index) => {
            const Icon = feature.icon
            return (
              <motion.div
                key={feature.title}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.5, delay: 0.7 + index * 0.1 }}
                className="group relative overflow-hidden rounded-xl border border-border bg-card/70 p-6 text-left backdrop-blur-md transition-colors hover:border-primary/30 hover:bg-card/90"
              >
                <div className="absolute inset-0 bg-gradient-to-br from-primary/5 to-transparent opacity-0 transition-opacity group-hover:opacity-100" />
                <div className="relative">
                  <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-primary/10">
                    <Icon className="h-5 w-5 text-primary" />
                  </div>
                  <h3 className="mt-4 text-sm font-semibold text-foreground">
                    {feature.title}
                  </h3>
                  <p className="mt-2 text-sm leading-relaxed text-muted-foreground">
                    {feature.description}
                  </p>
                </div>
              </motion.div>
            )
          })}
        </motion.div>
      </main>

      <footer className="relative z-10 mt-24 pb-8">
        <p className="text-xs text-muted-foreground/50">
          CarbonIQ - Industrial Carbon Intelligence
        </p>
      </footer>
    </div>
  )
}
