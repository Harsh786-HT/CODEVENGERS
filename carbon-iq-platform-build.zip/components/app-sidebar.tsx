"use client"

import Link from "next/link"
import Image from "next/image"
import { usePathname } from "next/navigation"
import {
  LayoutDashboard,
  Upload,
  Activity,
  Brain,
  Zap,
  DollarSign,
  Leaf,
} from "lucide-react"
import { cn } from "@/lib/utils"

const navItems = [
  { href: "/dashboard", label: "Dashboard", icon: LayoutDashboard },
  { href: "/dashboard/upload", label: "Data Upload", icon: Upload },
  { href: "/dashboard/signals", label: "Signal Monitoring", icon: Activity },
  { href: "/dashboard/prediction", label: "AI Prediction", icon: Brain },
  { href: "/dashboard/optimization", label: "Optimization", icon: Zap },
  { href: "/dashboard/financial", label: "Financial Impact", icon: DollarSign },
]

export function AppSidebar() {
  const pathname = usePathname()

  return (
    <aside className="fixed inset-y-0 left-0 z-30 flex w-64 flex-col overflow-hidden border-r border-border bg-sidebar">
      {/* Sidebar texture */}
      <div className="pointer-events-none absolute inset-0">
        <Image
          src="/images/sidebar-texture.jpg"
          alt=""
          fill
          sizes="256px"
          className="object-cover opacity-10"
        />
        <div className="absolute inset-0 bg-sidebar/90" />
      </div>

      <div className="relative z-10 flex h-16 items-center gap-2.5 border-b border-border px-6">
        <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-primary">
          <Leaf className="h-4 w-4 text-primary-foreground" />
        </div>
        <Link href="/" className="text-lg font-bold tracking-tight text-foreground">
          CarbonIQ
        </Link>
      </div>
      <nav className="relative z-10 flex-1 space-y-1 px-3 py-4">
        <p className="mb-3 px-3 text-xs font-semibold uppercase tracking-wider text-muted-foreground">
          Platform
        </p>
        {navItems.map((item) => {
          const isActive =
            pathname === item.href ||
            (item.href !== "/dashboard" && pathname.startsWith(item.href))
          const Icon = item.icon

          return (
            <Link
              key={item.href}
              href={item.href}
              className={cn(
                "flex items-center gap-3 rounded-lg px-3 py-2.5 text-sm font-medium transition-colors",
                isActive
                  ? "bg-primary/10 text-primary"
                  : "text-muted-foreground hover:bg-secondary hover:text-foreground"
              )}
            >
              <Icon className="h-4 w-4 shrink-0" />
              {item.label}
            </Link>
          )
        })}
      </nav>
      <div className="relative z-10 border-t border-border p-4">
        <div className="rounded-lg bg-secondary/50 p-3 backdrop-blur-sm">
          <p className="text-xs font-medium text-muted-foreground">System Status</p>
          <div className="mt-1.5 flex items-center gap-2">
            <div className="h-2 w-2 animate-pulse rounded-full bg-primary" />
            <p className="text-xs text-foreground">All systems operational</p>
          </div>
        </div>
      </div>
    </aside>
  )
}
