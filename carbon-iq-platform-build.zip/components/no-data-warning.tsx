"use client"

import Link from "next/link"
import { Upload, AlertTriangle } from "lucide-react"
import { motion } from "framer-motion"
import { Button } from "@/components/ui/button"

export function NoDataWarning() {
  return (
    <motion.div
      initial={{ opacity: 0, scale: 0.95 }}
      animate={{ opacity: 1, scale: 1 }}
      transition={{ duration: 0.4 }}
      className="mt-8 flex flex-col items-center justify-center rounded-xl border border-border bg-card/50 py-24 backdrop-blur-sm"
    >
      <div className="flex h-16 w-16 items-center justify-center rounded-2xl bg-secondary">
        <AlertTriangle className="h-8 w-8 text-muted-foreground" />
      </div>
      <h2 className="mt-6 text-xl font-semibold text-foreground">
        No Data Uploaded
      </h2>
      <p className="mt-2 max-w-sm text-center text-sm leading-relaxed text-muted-foreground">
        Upload a CSV file with operational parameters to begin monitoring carbon
        emissions and running AI predictions.
      </p>
      <Button asChild className="mt-6 gap-2">
        <Link href="/dashboard/upload">
          <Upload className="h-4 w-4" />
          Upload CSV Data
        </Link>
      </Button>
    </motion.div>
  )
}
