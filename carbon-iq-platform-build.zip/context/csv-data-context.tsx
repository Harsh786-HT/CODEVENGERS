"use client"

import React, { createContext, useContext, useState, useCallback, useMemo } from "react"

export interface CsvRecord {
  energy_kwh: number
  operating_hours: number
  idle_percentage: number
  avg_temperature: number
  machine_noise_db: number
  production_units: number
}

export interface Analytics {
  totalRecords: number
  totalEmission: number
  totalEnergy: number
  totalProduction: number
  avgEmission: number
  avgEnergy: number
  avgTemperature: number
  avgNoise: number
  avgIdlePercent: number
  avgEfficiency: number
  carbonIntensity: number
  peakEnergy: number
  peakEmission: number
  minEnergy: number
  energyStdDev: number
  tempStdDev: number
  anomalyIndices: number[]
  riskLevel: "low" | "moderate" | "high" | "critical"
  efficiencyGrade: string
}

const EMISSION_FACTOR = 0.42

function computeStdDev(values: number[], mean: number): number {
  const variance = values.reduce((sum, v) => sum + (v - mean) ** 2, 0) / values.length
  return Math.sqrt(variance)
}

function computeAnalytics(data: CsvRecord[]): Analytics {
  const n = data.length
  const emissions = data.map((r) => r.energy_kwh * EMISSION_FACTOR)
  const totalEmission = emissions.reduce((s, v) => s + v, 0)
  const totalEnergy = data.reduce((s, r) => s + r.energy_kwh, 0)
  const totalProduction = data.reduce((s, r) => s + r.production_units, 0)
  const avgEnergy = totalEnergy / n
  const avgEmission = totalEmission / n
  const avgTemperature = data.reduce((s, r) => s + r.avg_temperature, 0) / n
  const avgNoise = data.reduce((s, r) => s + r.machine_noise_db, 0) / n
  const avgIdlePercent = data.reduce((s, r) => s + r.idle_percentage, 0) / n
  const avgEfficiency = 100 - avgIdlePercent
  const carbonIntensity = totalProduction > 0 ? totalEmission / totalProduction : 0
  const peakEnergy = Math.max(...data.map((r) => r.energy_kwh))
  const peakEmission = Math.max(...emissions)
  const minEnergy = Math.min(...data.map((r) => r.energy_kwh))
  const energyStdDev = computeStdDev(data.map((r) => r.energy_kwh), avgEnergy)
  const tempStdDev = computeStdDev(data.map((r) => r.avg_temperature), avgTemperature)

  // Anomaly detection: records where energy > mean + 1.5 * stdDev
  const threshold = avgEnergy + 1.5 * energyStdDev
  const anomalyIndices = data
    .map((r, i) => (r.energy_kwh > threshold ? i : -1))
    .filter((i) => i >= 0)

  // Risk level based on carbon intensity and anomaly count
  const anomalyRate = anomalyIndices.length / n
  let riskLevel: Analytics["riskLevel"] = "low"
  if (anomalyRate > 0.2 || carbonIntensity > 0.5) riskLevel = "critical"
  else if (anomalyRate > 0.1 || carbonIntensity > 0.3) riskLevel = "high"
  else if (anomalyRate > 0.05 || carbonIntensity > 0.15) riskLevel = "moderate"

  let efficiencyGrade = "A+"
  if (avgEfficiency < 60) efficiencyGrade = "D"
  else if (avgEfficiency < 70) efficiencyGrade = "C"
  else if (avgEfficiency < 80) efficiencyGrade = "B"
  else if (avgEfficiency < 90) efficiencyGrade = "A"

  return {
    totalRecords: n,
    totalEmission,
    totalEnergy,
    totalProduction,
    avgEmission,
    avgEnergy,
    avgTemperature,
    avgNoise,
    avgIdlePercent,
    avgEfficiency,
    carbonIntensity,
    peakEnergy,
    peakEmission,
    minEnergy,
    energyStdDev,
    tempStdDev,
    anomalyIndices,
    riskLevel,
    efficiencyGrade,
  }
}

interface CsvDataContextType {
  data: CsvRecord[]
  setData: (data: CsvRecord[]) => void
  hasData: boolean
  analytics: Analytics | null
  optimizedData: CsvRecord[] | null
  optimizedAnalytics: Analytics | null
  runOptimization: () => void
  isOptimized: boolean
}

const CsvDataContext = createContext<CsvDataContextType | undefined>(undefined)

export function CsvDataProvider({ children }: { children: React.ReactNode }) {
  const [data, setData] = useState<CsvRecord[]>([])
  const [optimizedData, setOptimizedData] = useState<CsvRecord[] | null>(null)
  const [isOptimized, setIsOptimized] = useState(false)

  const analytics = useMemo(() => (data.length > 0 ? computeAnalytics(data) : null), [data])
  const optimizedAnalytics = useMemo(
    () => (optimizedData ? computeAnalytics(optimizedData) : null),
    [optimizedData]
  )

  const runOptimization = useCallback(() => {
    if (data.length === 0) return
    const optimized = data.map((record) => ({
      ...record,
      energy_kwh: +(record.energy_kwh * 0.88).toFixed(2),
      idle_percentage: +Math.max(0, record.idle_percentage - 10).toFixed(2),
      avg_temperature: +(record.avg_temperature * 0.95).toFixed(2),
    }))
    setOptimizedData(optimized)
    setIsOptimized(true)
  }, [data])

  return (
    <CsvDataContext.Provider
      value={{
        data,
        setData,
        hasData: data.length > 0,
        analytics,
        optimizedData,
        optimizedAnalytics,
        runOptimization,
        isOptimized,
      }}
    >
      {children}
    </CsvDataContext.Provider>
  )
}

export function useCsvData() {
  const context = useContext(CsvDataContext)
  if (context === undefined) {
    throw new Error("useCsvData must be used within a CsvDataProvider")
  }
  return context
}

export { EMISSION_FACTOR }
